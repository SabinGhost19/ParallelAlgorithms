#ifndef WORKER_H
#define WORKER_H

#include "common.h"

void *worker_function(void *arg);

#endif // WORKER_H
