#ifndef FEED_H
#define FEED_H

#include "common.h"

void proceseaza_feed(int thread_idx, int user_id);
int similaritate(const char *s1, const char *s2);

#endif // FEED_H
